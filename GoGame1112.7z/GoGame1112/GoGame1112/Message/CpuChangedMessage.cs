﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Message
{
    public class CpuChangedMessage
    {
    public string NewCpuState { get; set; }
    }
}