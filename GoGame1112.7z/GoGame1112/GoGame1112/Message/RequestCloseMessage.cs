﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Message
{
 public class RequestCloseMessage
 {
    public string Reason { get; set; }
 }
}