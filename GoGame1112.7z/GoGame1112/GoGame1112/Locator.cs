﻿using GoGame1112.Base;
using GoGame1112.DataBase;
using GoGame1112.Dispatcher;
using GoGame1112.Services.MessageBox;
using GoGame1112.Services.View;
using GoGame1112.Views.Edit.Logic;
using GoGame1112.Views.Edit.Logic.EditCpuWindowProvider;
using GoGame1112.Views.ShowCpuList.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112
{
  public static class Locator
  {
        public static IViewModel ViewModel { get; } = new ViewModel();
    /*public static IDataBase DataBase { get; } = new DataBase();*/
    public static IDispatcherHelper DispatcherHelper { get; } = new DispatcherHelper();
    public static IMessageBoxService MessageBoxService { get; } = new MessageBoxService();
    public static IViewService ViewService { get; } = new ViewService();
    public static IEditWindowProvider EditWindowProvider { get; } = new EditCpuWindowProvider();
    public static IShowCpuListWindowProvider ShowCpuListWindowProvider { get; } = new ShowCpuListWindowProvider();      

    }
}
