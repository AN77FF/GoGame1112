﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Dispatcher
{
 public interface IDispatcherHelper
	{
		void Invoke(Action action);
	}
}
