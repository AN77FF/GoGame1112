﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GoGame1112.Services.View
{
public interface IViewService
{
    void Show();
}
}