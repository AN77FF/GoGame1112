﻿using GoGame1112.DataBase;
using GoGame1112;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Serialization;
using GoGame1112.Game;
using GoGame1112.Models;
using System.Runtime.Remoting.Messaging;
using GoGame1112.Message;
using GoGame1112.Services.MessageBox;

namespace GoGame1112.Services.View
{
	public class WindowModel
    {
    public string Title { get; set; }
    public double Width { get; set; } = 800;
    public double Height { get; set; } = 600;

    public WindowModel(string title)
    {
        Title = title;
    }
    public WindowModel(string title, double width, double height)
    {
        Title = title;
        Width = width;
        Height = height;
    }
    }
}


