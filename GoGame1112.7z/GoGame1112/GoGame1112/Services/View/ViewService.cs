﻿using GoGame1112.Game;
using GoGame1112.Services.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GoGame1112.Services.View
{
  public class ViewService : IViewService
  {
    public void Show()
    {
        MainWindow mainWindow = new MainWindow();
        mainWindow.DataContext = new GoViewModel(19);
        mainWindow.Show();
    }
  }
}