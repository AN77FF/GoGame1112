﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Services.MessageBox
{
		public interface IMessageBoxService
		{
			void ShowMessage(string message, string title);
		}
}

