﻿using GoGame1112.Enities;
using GoGame1112.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Views.Edit.Logic.EditCpuWindowProvider
{
    public class EditCpuWindowProvider : IEditWindowProvider
    {
    public void ShowEditWindow()
    {
        EditCpuWindow window = new EditCpuWindow();
        window.ShowDialog();
    }

        public void ShowEditWindow(CpuModels models)
        {
            throw new NotImplementedException();
        }

        public void ShowEditWindow(object value)
        {
            throw new NotImplementedException();
        }
    }
}
