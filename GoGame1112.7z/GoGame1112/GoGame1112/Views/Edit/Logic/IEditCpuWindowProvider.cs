﻿using GoGame1112.Enities;
using GoGame1112.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Views.Edit.Logic
{
    public interface IEditWindowProvider
    {
        void ShowEditWindow(CpuModels models);
        void ShowEditWindow(object value);
    }
}

