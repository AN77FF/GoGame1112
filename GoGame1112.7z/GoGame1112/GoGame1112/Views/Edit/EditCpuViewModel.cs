﻿using GoGame1112.Base;
using GoGame1112.Enities;
using GoGame1112.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GoGame1112.Views.Edit
{
    public class EditCpuViewModel : ViewModel
    {
        public CpuModels CpuModel { get; set; }
        public ICommand SaveCommand { get; }

        public EditCpuViewModel(CpuModels model)
        {
            CpuModel = model;

           
        }

        public void SaveChanges()
        {

            CpuModel.Save();
            MessageBox.Show($"Сохранено: {CpuModel.ToString()}");
        }
    }
}