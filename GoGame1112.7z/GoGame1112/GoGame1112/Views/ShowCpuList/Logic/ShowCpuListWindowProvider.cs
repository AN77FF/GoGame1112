﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Views.ShowCpuList.Logic
{
 public class ShowCpuListWindowProvider : IShowCpuListWindowProvider
 {
    public void ShowCpuList()
    {
        ShowCpuListWindow window = new ShowCpuListWindow();
        window.DataContext = new ShowCpuListViewModel();
        window.ShowDialog(); 
    }
 }
}

