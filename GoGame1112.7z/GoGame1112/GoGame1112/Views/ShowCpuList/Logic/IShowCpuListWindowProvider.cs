﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Views.ShowCpuList.Logic
{
 public interface IShowCpuListWindowProvider
 {
    void ShowCpuList();
 }
}
