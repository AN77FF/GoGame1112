﻿using GoGame1112.Enities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Views.ShowCpuList
{
    public class DemoModel
    {
        public string Name { get; set; }
        public int Age { get; set; }

    }
}

