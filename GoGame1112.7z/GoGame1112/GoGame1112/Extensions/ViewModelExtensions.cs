﻿using GoGame1112.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Extensions
{
 public static class ViewModelExtensions
 {
    public static void UpdateData<T>(this ViewModelT<T> viewModel, T newData)
    {
        viewModel.Data = newData;
    }
 }
}
