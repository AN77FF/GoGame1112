﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Extensions
{
 public static class EnumerableExtensions
 {
    public static IEnumerable<T> WhereNotEmpty<T>(this IEnumerable<T> source)
    {
        return source != null ? source.Where(item => item != null) : Enumerable.Empty<T>();
    }
 }
}