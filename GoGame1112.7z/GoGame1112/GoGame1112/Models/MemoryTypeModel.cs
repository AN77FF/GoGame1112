﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Models
{
 public class MemoryTypeModel
 {
    public string Type { get; set; }
    public int SizeInMB { get; set; } 

    public override string ToString() => $"{Type} ({SizeInMB} MB)";
 }
}