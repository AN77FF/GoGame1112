﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Models
{
 public class CpuModels
 {
    public string Name { get; set; }
    public int SkillLevel { get; set; } 
    public string Strategy { get; set; } 

    public override string ToString() => $"{Name} (Level: {SkillLevel}, Strategy: {Strategy})";

        internal void Save()
        {
            throw new NotImplementedException();
        }
    }
}