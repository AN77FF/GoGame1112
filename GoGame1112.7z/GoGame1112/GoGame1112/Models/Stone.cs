﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Models
{
		public class Stone
		{
			public string Color { get; set; }
			public int X { get; set; }
			public int Y { get; set; }
		}
}


