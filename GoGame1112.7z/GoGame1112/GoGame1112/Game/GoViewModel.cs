﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls.Primitives;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows;
using GoGame1112.Models;
using GoGame1112.DataBase;
using GoGame1112.Base;
using GoGame1112.Enities;

namespace GoGame1112.Game
{
 public class GoViewModel : ViewModel
 {
    public GoBoard Board { get; private set; }
    public Cpu Ai { get; private set; }
    public ICommand PlaceStoneCommand { get; private set; }

    public GoViewModel(int size)
    {
        Board = new GoBoard(size);
        Ai = new Cpu(Board);
       /*PlaceStoneCommand = new RelayCommand(ExecutePlaceStone);*/
    }
      
        private void ExecutePlaceStone()
    {
     
        Ai.MakeMove();
        OnPropertyChanged(nameof(Board));
    }
 }
}