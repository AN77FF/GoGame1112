﻿using GoGame1112.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.DataBase
{
public interface IDataBase
{
    void Save(string filePath);
    void Load(string filePath);
}
}
