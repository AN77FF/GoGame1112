﻿using GoGame1112.DataBase;
using GoGame1112.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace GoGame1112.DataBase
{
public class DataBase : IDataBase
{
    private GoBoard _board;

    public DataBase(GoBoard board)
    {
        _board = board;
    }

    public void Save(string filePath)
    {
        
        using (var writer = new StreamWriter(filePath))
        {
            XmlSerializer serializer = new XmlSerializer(typeof(GoBoard));
            serializer.Serialize(writer, _board);
        }
    }

    public void Load(string filePath)
    {
        using (var reader = new StreamReader(filePath))
        {
            XmlSerializer serializer = new XmlSerializer(typeof(GoBoard));
            _board = (GoBoard)serializer.Deserialize(reader);
        }
    }
}
}