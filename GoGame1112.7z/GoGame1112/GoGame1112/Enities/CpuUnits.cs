﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Enities
{
 public class CpuUnit
 {
    public string Name { get; set; }
    public int Strength { get; set; }
 }
}

