﻿using GoGame1112.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoGame1112.Enities
{
 public class Cpu
 {
    private GoBoard _board;

    public Cpu(GoBoard board)
    {
        _board = board;
    }

        public int Speed { get; internal set; }
        public string Name { get; internal set; }

        public void MakeMove()
    {
       
        Random random = new Random();
        int x, y;

        do
        {
            x = random.Next(0, _board.Size);
            y = random.Next(0, _board.Size);
        } while 
        
        (_board.Stones[x, y] != null);

        _board.PlaceStone(x, y, new Models.Stone { Color = "Black" });
    }
 }
}
